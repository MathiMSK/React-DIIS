import { createContext } from "react";
const facultyContext = createContext(null);
export default facultyContext;

